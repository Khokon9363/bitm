<?php
   session_start();
   if (isset($_SESSION['id']) == null) {
       header('Location:index.php');
   }
   require_once '../../app/classes/category.php';
   use  App\classes\Category;
   
   $addCategoryMassage='';
   if (isset($_POST['btn'])) {
        $addCategoryMassage=Category::addCategory($_POST);
   }



?>


<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="../../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
       .animation-bro{
          height: 600px;
          width: 600px;
          animation-name: hello;
          animation-duration: 10s;
          animation-iteration-count: infinite;
           }
       @keyframes hello{
              0%{background-color: yellow;width: 600px;margin-left: -100px;margin-top: 0;}
              50%{background-color: orange;width: 700px;margin-left: 100px;margin-top: 100px;}
              100%{background-color: blue;width: 600px;margin-left: 0;margin-top: 0;}
           }
    </style>
</head>
<body>
    
   <?php include 'includes/menu.php'; ?>
<h3 style="color: green;text-align: center;"><?php echo $addCategoryMassage; ?></h3>
   <div class="container">
    <div class="row">
      <div class="col-sm-7 m-auto">
        <div class="card" style="margin-top: 50px;box-shadow:15px 15px 15px black;border-radius: 50px 7px 60px 7px;">
          <div class="card-body">
      <form action="" method="post"> 
          <div class="form-group row"> 
                   <label for="Email" class="col-sm-4 col-form-label h1"> Category Name </label> 
               <div class="col-sm-8"> 
                   <input type="text" class="form-control" id="Email" name="category_name"> 
             </div> 
          </div> 
          <div class="form-group row"> 
                 <label for="Password" class="col-sm-4 col-form-label h1"> Category Description </label> 
             <div class="col-sm-8 col-md-8 col-lg-8 col-xl-8"> 
               <textarea id="Password" class="form-control" name="category_description" style="width: 100%;height: 130px;"></textarea> 
             </div> 
          </div> 
          <div class="form-group row"> 
                   <label class="col-sm-4 col-form-label h1"> Publication status </label> 
             <div class="col-sm-8"> 
                   <input type="radio" name="status" value="1"> Published
                   <input type="radio" name="status" value="0"> Unpublished
             </div> 
          </div>
          <div class="form-group row"> 
             <div class="col-sm-4"></div>
             <div class="col-sm-8"> 
               <button type="submit" class="btn btn-success btn-block" id="btn" name="btn"> Save Category </button> 
             </div> 
          </div> 
        </form>

          </div>
        </div>
      </div>
    </div>
  </div>

    <script src="../../vendor/jquery/jquery.min.js"></script>
    <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../../vendor/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>