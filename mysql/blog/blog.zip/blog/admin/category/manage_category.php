<?php
   session_start();
   if (isset($_SESSION['id']) == null) {
       header('Location:index.php');
   }
   require_once '../../app/classes/category.php';
   use  App\classes\Category;

   $viewCategoryQuery=Category::viewCategory();
  
  $deleteCategoryMassage='';
  if (isset($_GET['delete'])) {
      $id=$_GET['id'];
      $deleteCategoryMassage=Category::deleteCategory($id);
  }


?>


<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="../../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    
   <?php include 'includes/menu.php'; ?>
 <h3 style="text-align: center;color: red;"><?php echo $deleteCategoryMassage; ?></h3>
   <div class="container">
      <div class="card col-sm-8 m-auto">
       <table class="table table-striped table-bordered mt-3 text-center"> 
  <thead class="table-dark"> 
    <tr> 
      <th scope="col"> SL NO </th> 
      <th scope="col"> Category Name </th> 
      <th scope="col"> Category Description </th>
      <th scope="col"> Publication Status </th> 
      <th scope="col"> Action </th> 
    </tr> 
  </thead>
<?php 
  $i=1;
  while ($viewCategoryQueryFetch=mysqli_fetch_assoc($viewCategoryQuery)) { ?> 
  <tbody> 
    <tr> 
      <th scope="row"><?php echo $i++; ?></th> 
      <td><?php echo $viewCategoryQueryFetch['category_name']; ?></td>
      <td><?php echo $viewCategoryQueryFetch['category_description']; ?></td> 
      <td>
        <?php
              if ($viewCategoryQueryFetch['status'] == 1) {
                   echo 'Published';
              } else {
                   echo 'Unpublished';
              }
              
         
         ?>
      </td> 
      <td>
        <a href="edit_category.php?id=<?php echo $viewCategoryQueryFetch['id']; ?>">Edit</a>
        <a href="?delete=true&id=<?php echo $viewCategoryQueryFetch['id']; ?>" onclick="return confirm('Are you sure to delete this Category ?') ">Delete</a>
      </td>
    </tr>
  </tbody>
<?php } ?> 
  </table>
     </div>
   </div>

    <script src="../../vendor/jquery/jquery.min.js"></script>
    <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../../vendor/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>