<?php
  session_start();
  if (isset($_SESSION['id'])) {
      header('Location:dashboard.php');
  }

  require_once '../app/classes/Login.php';
  use App\classes\Login;
  
  $loginMassage='';
  if (isset($_POST['btn'])) {
       $loginMassage=Login::login($_POST);
  }


?>


<!DOCTYPE html>
<html lang="en">
<head>
	  <title>Admin Login</title>
	  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
    	.card{transform: rotateY(-15deg) skew(-15deg);transition: .7s;}
    	.card:hover{transform: rotateY(360deg) scale(1.5);}
    </style>
</head>
<body>
  <div class="container">
  	<div class="row">
  		<div class="col-sm-6 m-auto">
  			<div class="card" style="margin-top: 250px;box-shadow:25px 25px 15px black;border-radius: 50px 7px 60px 7px;">
  				<div class="card-title">
  					<div class="text-center"><i><b>Admin Login</b></i></div>
  				</div>
  				<div class="card-body">
  <h4 style="color: red;text-align: center;"><?php echo $loginMassage; ?></h4>
  		<form action="" method="post"> 
	        <div class="form-group row"> 
	                 <label for="Email" class="col-sm-3 col-form-label h1">Email</label> 
	             <div class="col-sm-9"> 
	                 <input type="email" class="form-control" id="Email" name="email"> 
		         </div> 
	        </div> 
	        <div class="form-group row"> 
		             <label for="Password" class="col-sm-3 col-form-label h1">Password</label> 
		         <div class="col-sm-9"> 
			         <input type="password" class="form-control" id="Password" name="password"> 
		         </div> 
	        </div> 
	        <div class="form-group row"> 
	        	 <div class="col-sm-3"></div>
		         <div class="col-sm-9"> 
			         <button type="submit" class="btn btn-success btn-block" id="btn" name="btn">Log in</button> 
		         </div> 
	        </div> 
        </form>

  				</div>
  			</div>
  		</div>
  	</div>
  </div>
    
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>