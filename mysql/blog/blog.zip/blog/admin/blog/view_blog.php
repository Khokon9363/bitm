<?php
   session_start();
   if (isset($_SESSION['id']) == null) {
       header('Location:index.php');
   }
   require_once '../../app/classes/blog.php';
   use  App\classes\Blog;
  

    $id=$_GET['id'];
    $viewOneblogInfoQuery=Blog::viewOneblogInfo($id);
    $viewOneblogInfoQueryFetch=mysqli_fetch_assoc($viewOneblogInfoQuery);

    $viewblogQuery=Blog::viewblog();
    $viewblogQueryFetch=mysqli_fetch_assoc($viewblogQuery);

?>


<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="../../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    
   <?php include 'includes/menu.php'; ?>
<h3 style="color: red;text-align: center;"><?php $deleteBlogMassage; ?></h3>
    <div class="container-fluid">
      <div class="card col-sm-12 m-auto">
       <table class="table table-striped table-bordered mt-3 text-center"> 
  <thead class="table-dark"> 
    <tr> 
      <th scope="col"> SL NO </th>
      <th scope="col"> Category Name </th> 
      <th scope="col"> Blog Title </th>
      <th scope="col"> Short Description </th> 
      <th scope="col"> Long Description </th> 
      <th scope="col"> Blog Image </th> 
      <th scope="col"> Publication Status </th>
    </tr> 
  </thead>
  <?php $i=1; ?>
  <tbody> 
    <tr> 
      <th scope="row"><?php echo $i++; ?></th> 
      <td><?php echo $viewblogQueryFetch['category_name']; ?></td>
      <td><?php echo $viewOneblogInfoQueryFetch['blog_title']; ?></td> 
      <td><?php echo $viewOneblogInfoQueryFetch['short_description']; ?></td>
      <td><?php echo $viewOneblogInfoQueryFetch['long_description']; ?></td>
      <td><img src="<?php echo $viewOneblogInfoQueryFetch['blog_image']; ?>" style="height: 150px;width: 150px;"></td> 
      <td>
         <?php
              if ($viewOneblogInfoQueryFetch['status'] == 1) {
                   echo 'Published';
              } else {
                   echo 'Unpublished';
              }
              
         
         ?>
      </td>
    </tr>
  </tbody>
  </table>
     </div>
   </div>

    <script src="../../vendor/jquery/jquery.min.js"></script>
    <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../../vendor/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>