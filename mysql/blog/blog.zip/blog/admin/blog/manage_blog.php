<?php
   session_start();
   if (isset($_SESSION['id']) == null) {
       header('Location:index.php');
   }
   require_once '../../app/classes/blog.php';
   use  App\classes\Blog;


   $viewblogQuery=Blog::viewBlog();
   
   // while ($viewblogQueryFetch=mysqli_fetch_assoc($viewblogQuery)) {
   //   echo "<pre>";
   //   print_r($viewblogQueryFetch);
   //   exit();
   // }


   
   $deleteBlogMassage='';
   if (isset($_GET['delete'])) {
       $id=$_GET['id'];
    $deleteBlogMassage=Blog::deleteBlog($id);
   }

?>


<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="../../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    
   <?php include 'includes/menu.php'; ?>
<h3 style="color: red;text-align: center;"><?php $deleteBlogMassage; ?></h3>
    <div class="container">
      <div class="card col-sm-8 m-auto">
       <table class="table table-striped table-bordered mt-3 text-center"> 
  <thead class="table-dark"> 
    <tr> 
      <th scope="col"> SL NO </th> 
      <th scope="col"> Category Name </th> 
      <th scope="col"> Blog Title </th>
      <th scope="col"> Publication Status </th>
      <td scope="col"> Action </td>
    </tr> 
  </thead>
<?php
  $i=1; 
  while ($viewblogQueryFetch=mysqli_fetch_assoc($viewblogQuery)) { ?> 
  <tbody> 
    <tr> 
      <th scope="row"><?php echo $i++; ?></th> 
      <td><?php echo $viewblogQueryFetch['category_name']; ?></td>
      <td><?php echo $viewblogQueryFetch['blog_title']; ?></td> 
      <td>
        <?php
              if ($viewblogQueryFetch['status'] == 1) {
                   echo 'Published';
              } else {
                   echo 'Unpublished';
              }
              
         
         ?>
      </td> 
      <td>
        <a href="edit_blog.php?id=<?php echo $viewblogQueryFetch['id']; ?>">Edit</a>
        <a href="view_blog.php?id=<?php echo $viewblogQueryFetch['id']; ?>">View</a>
        <a href="?delete=true&id=<?php echo $viewblogQueryFetch['id']; ?>" onclick="return confirm('Are you sure to delete this Category ?') ">Delete</a>
      </td>
    </tr>
  </tbody>
<?php } ?> 
  </table>
     </div>
   </div>

    <script src="../../vendor/jquery/jquery.min.js"></script>
    <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../../vendor/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>