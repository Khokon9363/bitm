<?php
   session_start();
   if (isset($_SESSION['id']) == null) {
       header('Location:index.php');
   }
   require_once '../../app/classes/blog.php';
   use  App\classes\Blog;
   
   $id=$_GET['id'];
   $editblogQuery=Blog::editBlog($id);
   $editblogQueryFetch=mysqli_fetch_assoc($editblogQuery);

   if (isset($_POST['btn'])) {
        Blog::updateBlog($_POST);
   }

 $getAllPublishedCategoryNameQuery=Blog::getAllPublishedCategoryName();


?>


<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="../../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    
   <?php include 'includes/menu.php'; ?>
   <div class="container">
    <div class="row">
      <div class="col-sm-7 m-auto">
        <div class="card" style="margin-top: 50px;box-shadow:15px 15px 15px black;border-radius: 50px 7px 60px 7px;">
          <div class="card-body">
      <form action="" method="post" name="editBlogForm"> 
          <div class="form-group row"> 
                   <label for="Email" class="col-sm-4 col-form-label h1"> Category Name </label> 
               <div class="col-sm-8"> 
                   <select id="Email" name="category_id">
                       <option disabled selected> --Choose blog name-- </option>
    <?php while ($publishedCategory=mysqli_fetch_assoc($getAllPublishedCategoryNameQuery)) { ?>
                       <option value="<?php echo $publishedCategory['id']; ?>">
                         <?php echo $publishedCategory['category_name']; ?>
                       </option>
        <?php } ?>
                   </select>
                   <input type="hidden" name="id" value="<?php echo $editblogQueryFetch['id']; ?>">
             </div> 
          </div> 
          <div class="form-group row"> 
                 <label for="title" class="col-sm-4 col-form-label h1"> Blog Title </label> 
             <div class="col-sm-8 col-md-8 col-lg-8 col-xl-8"> 
               <input type="text"  value="<?php echo $editblogQueryFetch['blog_title']; ?>" name="blog_title" id="title" class="form-control">
             </div> 
          </div>
          <div class="form-group row"> 
                 <label for="shortDes" class="col-sm-4 col-form-label h1"> Short Description </label> 
             <div class="col-sm-8 col-md-8 col-lg-8 col-xl-8"> 
               <textarea id="shortDes" class="form-control" name="short_description" style="width: 100%;height: 70px;"><?php echo $editblogQueryFetch['short_description']; ?>
               </textarea> 
             </div> 
          </div>
          <div class="form-group row"> 
                 <label for="longDes" class="col-sm-4 col-form-label h1"> Long Description </label> 
             <div class="col-sm-8 col-md-8 col-lg-8 col-xl-8"> 
               <textarea id="longDes" class="form-control textarea" name="long_description" style="width: 100%;height: 130px;"><?php echo $editblogQueryFetch['long_description']; ?>
               </textarea> 
             </div> 
          </div>
          <div class="form-group row"> 
                 <label for="blogImage" class="col-sm-4 col-form-label h1"> Blog Image </label> 
             <div class="col-sm-8 col-md-8 col-lg-8 col-xl-8"> 
               <input type="file" name="blog_image" id="blogImage"> 
                  <img src="<?php echo $editblogQueryFetch['blog_image']; ?>" style="height: 60px;width: 60px;">
             </div> 
          </div> 
          <div class="form-group row"> 
                   <label class="col-sm-4 col-form-label h1"> Publication status </label> 
             <div class="col-sm-8"> 
                   <input type="radio" name="status" value="1"> Published
                   <input type="radio" name="status" value="0"> Unpublished
             </div> 
          </div>
          <div class="form-group row"> 
             <div class="col-sm-4"></div>
             <div class="col-sm-8"> 
               <button type="submit" class="btn btn-success btn-block" id="btn" name="btn"> Update Blog </button> 
             </div> 
          </div> 
        </form>

          </div>
        </div>
      </div>
    </div>
  </div>

    <script src="../../vendor/jquery/jquery.min.js"></script>
    <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


<script src="../../tinymce/js/tinymce/tinymce.min.js"></script>
<script>tinymce.init({ selector:'.textarea' });</script>

  

    <script src="../../vendor/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript">
      ducument.forms['editBlogForm'].elements['category_id'].value='<?php echo $editblogQueryFetch['category_id']; ?>'
    </script>
</body>
</html>