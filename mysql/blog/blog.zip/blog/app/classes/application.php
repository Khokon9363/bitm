<?php 
  Namespace App\classes;

  class Application{
  	
  	 public function application(){

  	 	   $link=mysqli_connect('localhost','root','','blog');
  	 	   $sql=" SELECT * FROM blogs WHERE status=1 ";

  	 	   if (mysqli_query($link,$sql)) {
  	 	   	   $applicationQuery=mysqli_query($link,$sql);
  	 	   	   return $applicationQuery;
  	 	   } else {
  	 	   	   die('Query problem .'.mysqli_error($link));
  	 	   }
  	 	   
  	 	
  	 }




  }



 ?>