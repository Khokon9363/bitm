<?php
 Namespace App\classes;

 class Category{
 	
 	public function addCategory($data){
 		   $link=mysqli_connect('localhost','root','','blog');
 		   $sql=" INSERT INTO categorys (category_name,category_description,status) VALUES ('$data[category_name]','$data[category_description]','$data[status]') ";
 		   if (mysqli_query($link,$sql)) {
 			  $addCategoryMassage='Your Category Informations has been saved successfully .';
 			  return $addCategoryMassage;
 		   } else {
 			 die('Query problem .'.mysqli_error($link));
 		  }
 		
 	}
 	public function viewCategory(){
 		$link=mysqli_connect('localhost','root','','blog');
 		$sql=" SELECT * FROM categorys ";
 		if (mysqli_query($link,$sql)) {
 			$viewCategoryQuery=mysqli_query($link,$sql);
 			return $viewCategoryQuery;
 		} else {
 			die('Query problem .'.mysqli_error($link));
 		}
 		
 	}
 	public function deleteCategory($id){
 		$link=mysqli_connect('localhost','root','','blog');
 		$sql="DELETE FROM categorys WHERE id='$id' ";
 		if (mysqli_query($link,$sql)) {
 			$deleteCategoryMassage=' Your Selected Category has been deleted successfully . ';
 		} else {
 			die('Query problem .'.mysqli_error($link));
 		}
 	}
 	public function editCategory($id){
 		$link=mysqli_connect('localhost','root','','blog');
 		$sql=" SELECT * FROM categorys WHERE id='$id' ";
 		if (mysqli_query($link,$sql)) {
 			$editCategoryQuery=mysqli_query($link,$sql);
 		    return $editCategoryQuery;
 		} else {
 			die('Query problem .'.mysqli_error($link));
 		}
 		
 	}
 	  // public function updateCategory($data,$id)
 	public function updateCategory($data){
 		$link=mysqli_connect('localhost','root','','blog');
 		// $sql=" UPDATE categorys SET category_name='$data[category_name]',category_description='$data[category_description]',status='$data[status]' WHERE id='$id' ";
 		$sql=" UPDATE categorys SET category_name='$data[category_name]',category_description='$data[category_description]',status='$data[status]' WHERE id='$data[id]' ";
 		if (mysqli_query($link,$sql)) {
 			header('Location:manage_category.php');
 		} else {
 			die('Query problem .'.mysqli_error($link));
 		}
 		
 	}



 }

?>