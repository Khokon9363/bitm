<?php
 Namespace App\classes;

 class Blog{

 	public function addBlog($data){

 		$link=mysqli_connect('localhost','root','','blog');

           $fileName=$_FILES['blog_image']['name'];
           $directory='pics/';
           $imageUrl=$directory.$fileName;
           $filetype=pathinfo($fileName,PATHINFO_EXTENSION);
  

       if (file_exists($imageUrl)) {
           die('This file already Exist.Please select another file.');

       } else {
           if ($_FILES['blog_image']['size']>500000) {
             die('Your file size is too large.Please select a file with in 10 kilobite.');

           }else{
              if ($filetype !='jpg' && $filetype !='png' && $filetype !='JPG') {
                   die('Image type is not supported.Please use jpg or png or JPG .');

            }else{
              move_uploaded_file($_FILES['blog_image']['tmp_name'], $imageUrl);

              $sql=" INSERT INTO blogs (category_id,blog_title,short_description,long_description,blog_image,status) VALUES ('$data[category_id]','$data[blog_title]','$data[short_description]','$data[long_description]','$imageUrl','$data[status]') ";
 		   if (mysqli_query($link,$sql)) {
 		   	  $addBlogMassage=' Your blog informations has been saved successfully .';
 		   	  return $addBlogMassage;
 		   } else {
 		   	  die('Query problem .'.mysqli_error($link));
 		   }


            }
          }


       }

       
          		   
 		   
 		   
 	}


 	public function viewblog(){
 		   $link=mysqli_connect('localhost','root','','blog');
 		   // $sql=" SELECT * FROM blogs ";
 		   $sql=" SELECT b.*, c.category_name FROM blogs as b, categorys as c WHERE b.category_id=c.id ";
 		   
 		   if (mysqli_query($link,$sql)) {
 		   	   $viewblogQuery=mysqli_query($link,$sql);
 		   	   return $viewblogQuery;
 		   } else {
 		   	   die('Query problem .'.mysqli_error($link));
 		   }
 		   
 	}
 	public function deleteBlog($id){
 		   $link=mysqli_connect('localhost','root','','blog');
 		   $sql=" DELETE FROM blogs WHERE id='$id' ";
 		   if (mysqli_query($link,$sql)) {
 		   	   $deleteBlogMassage=' Your selected blog has been deleted successfully .';
 		   	   return $deleteBlogMassage;
 		   } else {
 		   	   die('Query problem .'.mysqli_error($link));
 		   }
 	}
 	public function editBlog($id){
 		   $link=mysqli_connect('localhost','root','','blog');
 		   $sql=" SELECT * FROM blogs WHERE id='$id' ";
 		   if (mysqli_query($link,$sql)) {
 		   	   $editblogQuery=mysqli_query($link,$sql);
 		   	   return $editblogQuery;
 		   } else {
 		   	   die('Query problem .'.mysqli_error($link));
 		   }
 	}
 	public function updateBlog($data){
 		   $link=mysqli_connect('localhost','root','','blog');
 		   $sql=" UPDATE blogs SET category_id='$data[category_id]',blog_title='$data[blog_title]',short_description='$data[short_description]',long_description='$data[long_description]',blog_image='pics/$data[blog_image]',status='$data[status]' WHERE id='$data[id]' ";
 		   if (mysqli_query($link,$sql)) {
 		   	    header('Location:manage_blog.php');
 		   } else {
 		   	    die('Query problem .'.mysqli_error($link));
 		   }
 		   
 	}
 	public function getAllPublishedCategoryName(){
 		   $link=mysqli_connect('localhost','root','','blog');
 		   $sql=" SELECT * FROM categorys WHERE status=1 ";

 		   if (mysqli_query($link,$sql)) {
 		   	    $getAllPublishedCategoryNameQuery=mysqli_query($link,$sql);
 		   	    return $getAllPublishedCategoryNameQuery;
 		   } else {
 		   	    die('Query problem .'.mysqli_error($link));
 		   }
 	}


  public function viewOneblogInfo($id){
       $link=mysqli_connect('localhost','root','','blog');
       $sql=" SELECT * FROM blogs WHERE id='$id' ";
       
       if (mysqli_query($link,$sql)) {
           $viewOneblogInfoQuery=mysqli_query($link,$sql);
           return $viewOneblogInfoQuery;
       } else {
           die('Query problem .'.mysqli_error($link));
       }
       
  }



 	
 }



?>