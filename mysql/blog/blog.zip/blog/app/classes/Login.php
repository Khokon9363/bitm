<?php
  Namespace App\classes;

 class Login{

 	   public function login($data){
 	   	        $link=mysqli_connect('localhost','root','','blog');
 	   	        $sql=" SELECT * FROM users WHERE email='$data[email]' AND password=md5('$data[password]') ";

 	   	        if (mysqli_query($link,$sql)) {
 	   	   	    $loginQuery=mysqli_query($link,$sql);
 	   	   	    $user=mysqli_fetch_assoc($loginQuery);

 	   	   	      if ($user) {
 	   	   	      	  session_start();
 	   	   	      	  $_SESSION['id']=$user['id'];
 	   	   	      	  $_SESSION['name']=$user['name'];
 	   	   	      	  header('Location:dashboard.php');
 	   	   	      } else {
 	   	   	      	  $loginMassage='Your Email or Password is Invalid .'.'<br/>'.'Please enter Valid Email & Password .'.'<br/>'.'Thank you .';
 	   	   	      	  return $loginMassage;
 	   	   	      }
 	   	   	      
 	   	        } else {
 	   	   	    die('Query problem .'.mysqli_error($link));
 	   	       }
 	   }
 	   public function logout($id){
 	   	        session_start();
 	   	        unset($_SESSION['id']);
 	   	        unset($_SESSION['name']);
 	   	        header('Location:index.php');
 	   }


 	
 	
 }




?>