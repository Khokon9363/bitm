<?php 
  session_start();
  if (isset($_SESSION['id']) ) {
      header('Location:dashboard.php');
  }

  require_once 'app/classes/signInUp.php';
  use App\classes\signInUp;
  
  $SignInMassage='';
  if (isset($_POST['btn'])) {
      $SignInMassage=signInUp::SignIn($_POST);
  }




 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title> Signin </title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="vendor/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="vendor/css/signin.css">
</head>
<body>
<br>
<h2 style="text-align: center;color: white;"><?php echo $SignInMassage; ?></h2>

<form action="" method="post">
  <div class="container">
    <div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
            <h5 class="card-title text-center">Sign In</h5>
            <form class="form-signin">
              <div class="form-label-group">
                <input type="email" id="inputEmail" name="email" class="form-control" placeholder="Email address" required autofocus>
                <label for="inputEmail">Email address</label>
              </div>

              <div class="form-label-group">
                <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required>
                <label for="inputPassword">Password</label>
              </div>

              <div class="form-label-group">
                <input type="radio" name="role" value="1" style="margin-left: 100px;"> Admin 
                <input type="radio" name="role" value="0" style="margin-left: 30px;"> Visitor <br>
              </div>

              <button class="btn btn-lg btn-primary btn-block text-uppercase" name="btn" type="submit">Sign in</button>
              <a class="d-block text-center mt-2 small" href="signup.php">Sign Up</a>
              <hr class="my-4">
              <button class="btn btn-lg btn-google btn-block text-uppercase" type="submit"><i class="fab fa-google mr-2"></i> Sign in with Google</button>
              <button class="btn btn-lg btn-facebook btn-block text-uppercase" type="submit"><i class="fab fa-facebook-f mr-2"></i> Sign in with Facebook</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</form>
  
   <script type="text/javascript" src="vendor/js/jquery.js"></script>
   <script type="text/javascript" src="vendor/js/popper.min.js"></script>
   <script type="text/javascript" src="vendor/js/bootstrap.js"></script>
</body>
</html>