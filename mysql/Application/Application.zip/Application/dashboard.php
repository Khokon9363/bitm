<?php 
 session_start();
 if (isset($_SESSION['id']) == null) {
 	  header('Location:index.php');
 }

  require_once 'app/classes/signInUp.php';
  use App\classes\signInUp;

  if (isset($_GET['logout']) ) {
  	   $id=$_GET['id'];
       signInUp::logOut($id);
  }


 ?>


    <h1>Hello <?php  echo $_SESSION['name']; ?></h1>

    <input type="hidden" value="<?php  echo $_SESSION['id']; ?>" style="border:none;font-size: 4rem;">


   <a href="?logout=true$id=<?php $_SESSION['id']; ?>;" style="text-decoration: none;"> 
   	<div style="width: 100%;height: 600px;background-color: yellow;box-sizing: border-box;font-size: 200px;letter-spacing: 83px;text-align: center;">Log Out</div>
   </a>