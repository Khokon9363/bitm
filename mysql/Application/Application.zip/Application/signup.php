<?php 
  session_start();
  if (isset($_SESSION['id']) ) {
      header('Location:dashboard.php');
  }

  require_once 'app/classes/signInUp.php';
  use App\classes\signInUp;

  if (isset($_POST['btn'])) {
      signInUp::SignUp($_POST);
  }




 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Sign Up</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="vendor/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="vendor/css/signup.css">
</head>
<body>

 <form action="" method="post">
  <div class="container">
    <div class="row">
      <div class="col-lg-10 col-xl-9 mx-auto">
        <div class="card card-signin flex-row my-5">
          <div class="card-img-left d-none d-md-flex">
             <!-- Background image for card set in CSS! -->
          </div>
          <div class="card-body">
            <h5 class="card-title text-center">Register</h5>
            <form class="form-signin">
              <div class="form-label-group">
                <input type="text" id="inputUserame" class="form-control" placeholder="Username" required autofocus name="name">
                <label for="inputUserame">Username</label>
              </div>

              <div class="form-label-group">
                <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address" required>
                <label for="inputEmail">Email address</label>
              </div>
              
              <hr>

              <div class="form-label-group">
                <input type="radio" name="role" value="1" style="margin-left: 100px;"> Admin 
                <input type="radio" name="role" value="0" style="margin-left: 30px;"> Visitor <br>
              </div>
              
              <div class="form-label-group">
                <input type="password" name="password" id="inputConfirmPassword" class="form-control" placeholder="Password" required>
                <label for="inputConfirmPassword"> Password </label>
              </div>

               <input type="hidden" name="created_at" value="<?php echo date('D-M-Y'); ?>">
               <input type="hidden" name="updated_at" value="<?php echo date('D-M-Y'); ?>">

              <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit" name="btn">Register</button>
              <a class="d-block text-center mt-2 small" href="index.php">Sign In</a>
              <hr class="my-4">
              <button class="btn btn-lg btn-google btn-block text-uppercase" type="submit"><i class="fab fa-google mr-2"></i> Sign up with Google</button>
              <button class="btn btn-lg btn-facebook btn-block text-uppercase" type="submit"><i class="fab fa-facebook-f mr-2"></i> Sign up with Facebook</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</form>

   <script type="text/javascript" src="vendor/js/jquery.js"></script>
   <script type="text/javascript" src="vendor/js/popper.min.js"></script>
   <script type="text/javascript" src="vendor/js/bootstrap.js"></script>
</body>
</html>