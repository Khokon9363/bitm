<?php
 Namespace App\classes; 

 class signInUp{
 	
 	public function SignUp($data){
 		   $link=mysqli_connect('localhost','root','','application');
 		   $sqlOfSave=" INSERT INTO users (name, email, role, password, created_at, updated_at) VALUES ('$data[name]', '$data[email]', '$data[role]', md5('$data[password]'), '$data[created_at]', '$data[updated_at]' ) ";

 		   if (mysqli_query($link,$sqlOfSave)) {
 		   	    $sqlOfSession=" SELECT * FROM users WHERE id='$data[id]' ";

 		   	    if (mysqli_query($link,$sqlOfSession)) {
 		   	    	 $SignUpQuery=mysqli_query($link,$sqlOfSession);
 		   	    	 $SignUpQueryFetch=mysqli_fetch_assoc($SignUpQuery);
 		   	    }
 		   	     if ($SignUpQueryFetch) {
 		   	    	  session_start();
 		   	    	  $_SESSION['id']=$SignUpQueryFetch['id'];
                      $_SESSION['name']=$SignUpQueryFetch['name'];
                      header('Location:dashboard.php');
 		   	    }
 		   	    

 		   } else {
 		   	   die('Query problem'.mysqli_error($link));
 		   }
 		   
 	}
 	public function SignIn($data){
 		   $link=mysqli_connect('localhost','root','','application');
 		   $sql=" SELECT * FROM users WHERE email='$data[email]' AND password=md5('$data[password]') AND role='$data[role]' ";

 		   if (mysqli_query($link,$sql)) {
 		   	   $SignInQuery=mysqli_query($link,$sql);
 		   	   $SignInQueryFetch=mysqli_fetch_assoc($SignInQuery);

 		   	   if ($SignInQueryFetch) {
 		   	   	    session_start();
 		   	   	    $_SESSION['id']=$SignInQueryFetch['id'];
 		   	   	    $_SESSION['name']=$SignInQueryFetch['name'];
 		   	   	    header('Location:dashboard.php');

 		   	   } else {
 		   	   	  $SignInMassage='Your inputed Email, Password or Role is Invalid .'.'<br>'.'Please Input Valid Email ,Password & Role Correctly ..';
 		   	   	  return $SignInMassage;
 		   	   }
 		   	   

 		   } else {
 		   	  die('Query problem'.mysqli_error($link));
 		   }
 		   
 	}
 	public function logOut($id){
 		   session_start();
 		   unset($_SESSION['id']);
 		   unset($_SESSION['name']);
 		   header('Location:index.php');
 	}






 }




 ?>