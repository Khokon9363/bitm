<?php 

 require_once 'sendmassage.php';
 use App\classes\SendMassage;

 if (isset($_POST['btn'])) {
 	   SendMassage::sendMassage($_POST);
 }
 $viewMassageQuery=SendMassage::viewMassage();


 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Massage Sending</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
  <meta http-equiv="refresh" content="">
</head>
<body>

	<div class="container">
		<div class="row" style="margin-top: 150px;">
			 <div class="card border-success m-auto" style="max-width: 25rem;">
             <div class="card-header text-center h2"> Reload Please </div>
             <div class="card-body text-success">
              
   <?php while ($viewMassageQueryFetch=mysqli_fetch_assoc($viewMassageQuery)) { ?>

             
             <div><?php echo $viewMassageQueryFetch['user_massage'].'<br>' ?></div>
             <small><?php echo date('h:i:sA').' ( '.date('D-M-Y').' )'.'<hr>' ?></small>

   <?php } ?>

              </div>
             </div>
		</div>

		<div class="row" style="margin-top: 150px;">
			 <div class="card border-success m-auto" style="max-width: 25rem;">
             <div class="card-header text-center h2"> Write Here </div>
             <div class="card-body text-success">
              
             <form action="" method="post">
                <textarea name="massage" class="form-control" cols="30" rows="6" placeholder="Please write your massage here"></textarea><br><br>
                <!-- <input type="time" name="time"> -->
                <input type="submit" name="btn" value="Send" class="btn btn-success btn-block">
             </form>

              </div>
             </div>
		</div>
	</div>


  <script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
  <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.js"></script>
</body>
</html>