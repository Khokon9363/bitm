<?php 
 Namespace App\classes;


  class SendMassage{
  	
        public function sendMassage($data){
        	   $link=mysqli_connect('localhost','root','','massagesending');
        	   $sql="INSERT INTO massages (massage) VALUES ('$data[massage]') ";

        	   if (mysqli_query($link,$sql)) {
        	   	    
        	   } else {
        	      die('Query problem '.mysqli_error($link));
        	   }
        	   
        }
        public function viewMassageUser(){
        	   $link=mysqli_connect('localhost','root','','massagesending');
        	   $sql="SELECT * FROM massages ";

        	   if (mysqli_query($link,$sql)) {
        	   	  $viewMassageQuery=mysqli_query($link,$sql);
        	   	  return $viewMassageQuery;
        	   	    
        	   } else {
        	      die('Query problem '.mysqli_error($link));
        	   }
        	   
        }
        public function sendMassageUser($data){
        	   $link=mysqli_connect('localhost','root','','massagesending');
        	   $sql="INSERT INTO user_massages (user_massage) VALUES ('$data[user_massage]') ";

        	   if (mysqli_query($link,$sql)) {
        	   	    
        	   } else {
        	      die('Query problem '.mysqli_error($link));
        	   }
        	   
        }
        public function viewMassage(){
        	   $link=mysqli_connect('localhost','root','','massagesending');
        	   $sql="SELECT * FROM user_massages ";

        	   if (mysqli_query($link,$sql)) {
        	   	  $viewMassageQuery=mysqli_query($link,$sql);
        	   	  return $viewMassageQuery;
        	   	    
        	   } else {
        	      die('Query problem '.mysqli_error($link));
        	   }
        	   
        }



  }







 ?>